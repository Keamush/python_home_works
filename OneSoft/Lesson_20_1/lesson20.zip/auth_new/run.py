from auth_new.front.windows import MainWindow


def main():
    start_window = MainWindow()
    start_window.mainloop()


if __name__ == '__main__':
    main()
